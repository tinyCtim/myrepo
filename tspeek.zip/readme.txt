
readme.txt - lrb - 10/3/2024

This is "Toby Speak," "the only language your cat will ever need."

tspeek.exe -v -u filename.typ

Both -v and -u are optional.

-v gives verbose reporting
-u "untranslates" a file into English

Put text files you've created that you want to translate into "Toby
Speak" in the same folder as the executable.

Examples:

tspeek.exe foo.txt 

translates from English to Toby Speak, producing foo.tbo and foo.htm

tspeek.exe -v -u bar.tbo

untranslates from Toby Speak to English, producing bar.txt and bar.htm
with verbose reporting

The program uses .dic dictionary files which contain the English / Toby
equivalents. Each entry has the form _foo_->~bar_

Toby Speak is written in C. Source at
http://primepuzzle.com/blog/tspeek.zip

Latest "news," Toby quotes, dynamic "dishunary" facility etc. at
http://primepuzzle.com/blog/all.dic.html

